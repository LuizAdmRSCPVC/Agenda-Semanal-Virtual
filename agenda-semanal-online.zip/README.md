# Agenda Semanal Online

Agenda web responsiva de segunda a domingo, com armazenamento persistente em arquivo JSON, edição/exclusão de compromissos e exportação da semana para PNG para compartilhar no WhatsApp.

## Recursos
- Acesso por link, sem login.
- Qualquer pessoa com o link pode visualizar, adicionar, editar e excluir compromissos.
- Navegação entre semanas, de segunda a domingo.
- Salva os dados no servidor.
- Exporta a programação como imagem PNG. Em navegadores compatíveis, abre o menu de compartilhamento; nos demais, baixa a imagem para anexar no WhatsApp.
- Layout responsivo para celular e computador.

## Publicar gratuitamente no Render
1. Crie um repositório no GitHub e envie todos os arquivos desta pasta.
2. Entre em https://render.com e escolha **New + → Blueprint**.
3. Conecte o repositório que contém `render.yaml`.
4. Confirme a criação do serviço. O Render instalará as dependências e publicará a aplicação.
5. Ao terminar, abra o endereço `.onrender.com` criado pelo Render e compartilhe esse link.

O `render.yaml` configura um disco persistente em `/var/data` para que os dados sobrevivam às reinicializações. O plano e a disponibilidade de discos podem mudar; confira os custos e limitações atuais do Render antes de publicar. Se o serviço for colocado em um plano sem disco persistente, defina `DATA_DIR` para um volume persistente.

## Executar localmente
Requer Node.js 18 ou superior.

```bash
npm install
npm start
```

Abra http://localhost:3000.

## Aviso importante de privacidade
Por escolha do projeto, não há login nem permissões individuais: qualquer pessoa que tiver o link pode alterar ou apagar a agenda. Não use para informações confidenciais. O armazenamento JSON é adequado para um uso simples e com baixo volume; não é uma solução multi-região nem um banco de dados transacional. Para muitos usuários simultâneos, migre para PostgreSQL e adicione controle de acesso.

## Como compartilhar a imagem
Clique em **Exportar imagem**. Em dispositivos/navegadores que aceitam compartilhamento de arquivos, selecione WhatsApp no menu. Caso contrário, um PNG será baixado; abra o WhatsApp e anexe a imagem manualmente.

## Limites conhecidos
- Os dados são compartilhados por todos que usam o mesmo link.
- A persistência depende de a hospedagem manter o volume configurado.
- A biblioteca de captura de imagem e as fontes web usam CDN; exportação pode depender de conexão com a internet.
