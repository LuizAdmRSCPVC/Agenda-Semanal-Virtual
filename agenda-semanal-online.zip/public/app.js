const DAYS = ["Segunda-feira","Terça-feira","Quarta-feira","Quinta-feira","Sexta-feira","Sábado","Domingo"];
const SHORT = ["SEG","TER","QUA","QUI","SEX","SÁB","DOM"];
let weekStart = mondayOf(new Date());
let entries = [];
let toastTimer;

const $ = id => document.getElementById(id);
const status = $("saveStatus");
function mondayOf(date) {
  const d = new Date(date.getFullYear(), date.getMonth(), date.getDate());
  const offset = (d.getDay() + 6) % 7;
  d.setDate(d.getDate() - offset);
  return d;
}
function keyFor(date) { return `${date.getFullYear()}-${String(date.getMonth()+1).padStart(2,"0")}-${String(date.getDate()).padStart(2,"0")}`; }
function dateAt(day) { const d = new Date(weekStart); d.setDate(d.getDate()+day); return d; }
function formatDate(date, options={day:"2-digit",month:"2-digit",year:"numeric"}) { return new Intl.DateTimeFormat("pt-BR",options).format(date); }
function rangeLabel() { return `${formatDate(dateAt(0))} a ${formatDate(dateAt(6))}`; }
function setStatus(message, state="") { status.className = `save-status ${state}`; status.lastElementChild.textContent = message; }
function showToast(message) { const t=$("toast"); t.textContent=message; t.classList.add("show"); clearTimeout(toastTimer); toastTimer=setTimeout(()=>t.classList.remove("show"),2600); }
function updateHeader() {
  $("weekTitle").textContent = `Semana de ${formatDate(dateAt(0),{day:"2-digit",month:"long"})}`;
  $("weekRange").textContent = rangeLabel();
  $("exportRange").textContent = rangeLabel();
  $("generatedAt").textContent = `Gerada em ${formatDate(new Date(),{day:"2-digit",month:"2-digit",year:"numeric"})}`;
}
async function loadWeek() {
  updateHeader(); setStatus("Carregando…");
  try {
    const res = await fetch(`/api/week?start=${keyFor(weekStart)}`);
    if (!res.ok) throw new Error("Falha ao carregar");
    const data = await res.json(); entries = data.entries || [];
    render(); setStatus("Dados sincronizados","saved");
  } catch (err) {
    setStatus("Erro de conexão","error"); showToast("Não foi possível carregar a agenda. Verifique a conexão.");
  }
}
async function persist() {
  setStatus("Salvando…");
  try {
    const res = await fetch("/api/week",{method:"PUT",headers:{"Content-Type":"application/json"},body:JSON.stringify({start:keyFor(weekStart),entries})});
    if (!res.ok) throw new Error("Falha ao salvar");
    setStatus("Salvo online","saved"); return true;
  } catch (err) {
    setStatus("Falha ao salvar","error"); showToast("Não foi possível salvar. Tente novamente."); return false;
  }
}
function render() {
  const grid = $("weekGrid"); grid.innerHTML="";
  const todayKey=keyFor(new Date());
  DAYS.forEach((day,index)=>{
    const d=dateAt(index), col=document.createElement("section");
    col.className="day-column"+(keyFor(d)===todayKey?" today":"");
    const head=document.createElement("div"); head.className="day-head";
    const name=document.createElement("div"); name.className="day-name"; name.textContent=day;
    const date=document.createElement("div"); date.className="day-date"; date.textContent=formatDate(d,{day:"2-digit",month:"short"}).replace(".","");
    head.append(name,date);
    const list=document.createElement("div"); list.className="day-events";
    const dayEntries=entries.filter(e=>e.day===index).sort((a,b)=>(a.time||"99:99").localeCompare(b.time||"99:99"));
    if (!dayEntries.length) { const empty=document.createElement("div"); empty.className="empty-day"; empty.textContent="Sem compromissos"; list.append(empty); }
    dayEntries.forEach(entry=>{
      const card=document.createElement("article"); card.className="event-card"; card.tabIndex=0; card.setAttribute("role","button"); card.setAttribute("aria-label",`Editar ${entry.title}`);
      const title=document.createElement("div"); title.className="event-title"; title.textContent=entry.title; card.append(title);
      if(entry.time){const time=document.createElement("div");time.className="event-time";time.textContent=entry.time;card.insertBefore(time,title);}
      if(entry.notes){const notes=document.createElement("div");notes.className="event-notes";notes.textContent=entry.notes;card.append(notes);}
      card.addEventListener("click",()=>openEdit(entry));
      card.addEventListener("keydown",e=>{if(e.key==="Enter"||e.key===" "){e.preventDefault();openEdit(entry);}});
      list.append(card);
    });
    col.append(head,list); grid.append(col);
  });
  updateHeader();
}
function openEdit(entry) {
  $("editId").value=entry.id; $("editDay").value=entry.day; $("editTime").value=entry.time||"";
  $("editTitle").value=entry.title; $("editNotes").value=entry.notes||""; $("editDialog").showModal();
}
function closeEdit() { $("editDialog").close(); }
$("entryForm").addEventListener("submit",async e=>{
  e.preventDefault();
  const title=$("entryTitle").value.trim(); if(!title)return;
  entries.push({id:crypto.randomUUID?crypto.randomUUID():String(Date.now()),day:Number($("entryDay").value),time:$("entryTime").value,title,notes:$("entryNotes").value.trim()});
  render();
  if(await persist()){ $("entryForm").reset(); $("entryDay").value="0"; showToast("Compromisso adicionado e salvo."); }
});
$("editForm").addEventListener("submit",async e=>{
  e.preventDefault(); const id=$("editId").value;
  const item=entries.find(x=>x.id===id); if(!item)return;
  item.day=Number($("editDay").value); item.time=$("editTime").value; item.title=$("editTitle").value.trim(); item.notes=$("editNotes").value.trim();
  render(); closeEdit(); if(await persist())showToast("Compromisso atualizado.");
});
$("deleteBtn").addEventListener("click",async()=>{
  const id=$("editId").value; if(!confirm("Deseja excluir este compromisso?"))return;
  entries=entries.filter(x=>x.id!==id); render(); closeEdit(); if(await persist())showToast("Compromisso excluído.");
});
document.querySelectorAll(".close-dialog").forEach(b=>b.addEventListener("click",closeEdit));
$("prevWeek").addEventListener("click",()=>{weekStart.setDate(weekStart.getDate()-7);loadWeek();});
$("nextWeek").addEventListener("click",()=>{weekStart.setDate(weekStart.getDate()+7);loadWeek();});
$("todayBtn").addEventListener("click",()=>{weekStart=mondayOf(new Date());loadWeek();});
$("exportBtn").addEventListener("click",async()=>{
  const btn=$("exportBtn"); btn.disabled=true; btn.textContent="Preparando imagem…";
  try {
    if(!window.html2canvas)throw new Error("Biblioteca de imagem indisponível");
    const canvas=await html2canvas($("agendaCanvas"),{backgroundColor:"#ffffff",scale:2,useCORS:true,logging:false});
    const blob=await new Promise(resolve=>canvas.toBlob(resolve,"image/png"));
    if(!blob)throw new Error("Não foi possível criar imagem");
    const filename=`agenda-semanal-${keyFor(weekStart)}.png`;
    const file=new File([blob],filename,{type:"image/png"});
    if(navigator.canShare && navigator.canShare({files:[file]})){
      await navigator.share({files:[file],title:"Agenda semanal",text:`Agenda semanal: ${rangeLabel()}`});
      showToast("Imagem pronta para compartilhar.");
    } else {
      const url=URL.createObjectURL(blob); const a=document.createElement("a"); a.href=url; a.download=filename; a.click(); URL.revokeObjectURL(url);
      showToast("Imagem baixada. Anexe o PNG no WhatsApp.");
    }
  } catch(err) {
    if(err.name!=="AbortError")showToast("Não foi possível compartilhar diretamente. Tente exportar novamente.");
  } finally {btn.disabled=false;btn.textContent="↓ Exportar imagem";}
});
loadWeek();