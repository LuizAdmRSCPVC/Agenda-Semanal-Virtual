const express = require("express");
const fs = require("fs");
const path = require("path");

const app = express();
const PORT = process.env.PORT || 3000;
const DATA_DIR = process.env.DATA_DIR || path.join(__dirname, "data");
const DATA_FILE = path.join(DATA_DIR, "agenda.json");

app.use(express.json({ limit: "1mb" }));
app.use(express.static(path.join(__dirname, "public")));

function ensureStore() {
  fs.mkdirSync(DATA_DIR, { recursive: true });
  if (!fs.existsSync(DATA_FILE)) {
    fs.writeFileSync(DATA_FILE, JSON.stringify({ weeks: {} }, null, 2));
  }
}
function readStore() {
  ensureStore();
  try { return JSON.parse(fs.readFileSync(DATA_FILE, "utf8")); }
  catch { return { weeks: {} }; }
}
function writeStore(data) {
  ensureStore();
  const tmp = DATA_FILE + ".tmp";
  fs.writeFileSync(tmp, JSON.stringify(data, null, 2));
  fs.renameSync(tmp, DATA_FILE);
}
function validWeekKey(key) {
  return typeof key === "string" && /^\d{4}-\d{2}-\d{2}$/.test(key);
}

app.get("/api/week", (req, res) => {
  const key = req.query.start;
  if (!validWeekKey(key)) return res.status(400).json({ error: "Data inicial inválida." });
  const store = readStore();
  res.json({ start: key, entries: store.weeks[key] || [] });
});

app.put("/api/week", (req, res) => {
  const { start, entries } = req.body || {};
  if (!validWeekKey(start) || !Array.isArray(entries)) {
    return res.status(400).json({ error: "Dados da semana inválidos." });
  }
  if (entries.length > 500) return res.status(400).json({ error: "Limite de compromissos excedido." });
  const clean = entries.map((item, i) => ({
    id: String(item.id || `${Date.now()}-${i}`).slice(0, 100),
    day: Number(item.day),
    time: String(item.time || "").slice(0, 5),
    title: String(item.title || "").trim().slice(0, 160),
    notes: String(item.notes || "").trim().slice(0, 500)
  })).filter(x => Number.isInteger(x.day) && x.day >= 0 && x.day <= 6 && x.title);
  const store = readStore();
  store.weeks[start] = clean;
  writeStore(store);
  res.json({ ok: true, start, count: clean.length });
});

app.get("/api/health", (_req, res) => res.json({ ok: true }));

app.get("*", (_req, res) => res.sendFile(path.join(__dirname, "public", "index.html")));

app.listen(PORT, "0.0.0.0", () => {
  ensureStore();
  console.log(`Agenda online rodando na porta ${PORT}`);
});